# Rwanda Vibe Media 3.2.2

## Render
This repository is intentionally Render-friendly: `package.json` is at the repository root.

- Build Command: `npm install`
- Start Command: `npm start`
- Node: 22+
- Set `JWT_SECRET` in Render.
- The application server is `mrw/server.js`.
- Public files are in `mrw/public/`.

## Private Messages
The site includes a WhatsApp-style one-to-one private Messages page:
- Login required.
- Search registered users.
- Send private text messages.
- Conversations are stored in SQLite.
- Automatic 2.5-second message refresh.
- Only conversation participants can read the messages.

## Important production storage note
The SQLite database is `mrw/media-rwanda.db` and uploads are in `mrw/uploads/`. On Render, use persistent storage or managed storage if you need these files/data to survive restarts and redeploys.
